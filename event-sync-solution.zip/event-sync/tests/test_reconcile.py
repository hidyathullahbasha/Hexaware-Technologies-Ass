"""Run with:  python3 -m unittest discover -s tests -v"""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import reconcile  # noqa: E402

DATA = os.path.join(os.path.dirname(__file__), "..", "data")


def load():
    with open(os.path.join(DATA, "crm_events.json")) as a, open(os.path.join(DATA, "calendar_events.json")) as b:
        return reconcile.reconcile(json.load(a), json.load(b))


class ReconcileTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.res = load()
        cls.by_crm = {m["source_records"]["crm"]: m for m in cls.res["meetings"] if m["source_records"]["crm"]}
        cls.by_cal = {i: m for m in cls.res["meetings"] for i in m["source_records"]["calendar"]}

    def conflict(self, m, field):
        return next((c for c in m["conflicts"] if c["field"] == field), None)

    def test_counts(self):
        s = self.res["stats"]
        self.assertEqual((s["meetings"], s["in_both"], s["crm_only"], s["calendar_only"]), (24, 17, 3, 4))
        self.assertEqual(s["calendar_duplicates_merged"], 1)

    def test_expected_pairs(self):
        pairs = {"CRM-1001": "CAL-A1", "CRM-1002": "CAL-A2", "CRM-1004": "CAL-A4", "CRM-1005": "CAL-A5",
                 "CRM-1006": "CAL-A7", "CRM-1007": "CAL-A8", "CRM-1008": "CAL-A9", "CRM-1009": "CAL-A10",
                 "CRM-1011": "CAL-A12", "CRM-1012": "CAL-A13", "CRM-1013": "CAL-A14", "CRM-1014": "CAL-A15",
                 "CRM-1015": "CAL-A16", "CRM-1016": "CAL-A17", "CRM-1017": "CAL-A20", "CRM-1018": "CAL-A21",
                 "CRM-1019": "CAL-A22"}
        for crm, cal in pairs.items():
            self.assertIn(cal, self.by_crm[crm]["source_records"]["calendar"], crm)

    def test_unmatched(self):
        for cid in ("CRM-1003", "CRM-1010", "CRM-1020"):
            self.assertEqual(self.by_crm[cid]["sources"], ["crm"])
        for cal in ("CAL-A3", "CAL-A18", "CAL-A11", "CAL-A19"):
            self.assertEqual(self.by_cal[cal]["sources"], ["calendar"])

    def test_recurring_instances_not_merged(self):
        self.assertNotEqual(self.by_cal["CAL-A3"]["id"], self.by_cal["CAL-A18"]["id"])

    def test_calendar_duplicate_merged(self):
        m = self.by_crm["CRM-1005"]
        self.assertEqual(m["source_records"]["calendar"], ["CAL-A5", "CAL-A6"])
        emails = {a["email"] for a in m["fields"]["attendees"]["value"]}
        self.assertIn("sandra.mills@pinnaclegp.com", emails)
        self.assertIsNotNone(self.conflict(m, "calendar_duplicate"))

    def test_format_and_location_conflict(self):
        m = self.by_crm["CRM-1002"]
        self.assertEqual(self.conflict(m, "format")["severity"], "high")
        self.assertEqual(m["format"], "virtual")
        self.assertIsNotNone(self.conflict(m, "location"))

    def test_compatible_locations_not_conflicts(self):
        for cid in ("CRM-1001", "CRM-1011", "CRM-1015", "CRM-1017", "CRM-1005"):
            self.assertIsNone(self.conflict(self.by_crm[cid], "location"), cid)

    def test_timezone_conversion_and_time_conflicts(self):
        m = self.by_crm["CRM-1004"]  # 19:00Z on 2025-03-13 is 15:00 EDT, CRM says 14:00
        self.assertEqual(m["start"], "2025-03-13T15:00:00-04:00")
        self.assertEqual(self.conflict(m, "start")["severity"], "warning")
        self.assertEqual(self.conflict(self.by_crm["CRM-1016"], "start")["severity"], "high")

    def test_malformed_inputs(self):
        self.assertEqual(self.by_crm["CRM-1008"]["start"][:10], "2025-03-15")  # '03-15/2025'
        self.assertEqual(self.by_cal["CAL-A11"]["end"], "2025-03-14T20:00:00-04:00")  # '...T20:00'
        raj = [a for a in self.by_crm["CRM-1015"]["fields"]["attendees"]["value"] if a["email"] and "raj" in a["email"]]
        self.assertEqual(raj[0]["email"], "raj.patel@atlasvc.com")
        guests = [a for a in self.by_crm["CRM-1017"]["fields"]["attendees"]["value"] if a["name"] == "external-guests"]
        self.assertFalse(guests[0]["valid"])

    def test_missing_fields_filled(self):
        m = self.by_crm["CRM-1007"]  # CRM has no time/location
        self.assertEqual(m["start"], "2025-03-18T15:00:00-04:00")
        self.assertEqual(m["location"], "Zoom")
        self.assertEqual(m["fields"]["start"]["note"], "CRM time missing - filled from calendar")

    def test_cancelled_vs_confirmed(self):
        m = self.by_crm["CRM-1009"]
        self.assertEqual(m["status"], "cancelled")
        self.assertEqual(self.conflict(m, "status")["severity"], "high")
        self.assertTrue(any(f["code"] == "reschedule_not_found" for f in m["quality_flags"]))

    def test_every_field_has_provenance(self):
        for m in self.res["meetings"]:
            for k, f in m["fields"].items():
                self.assertIn(f["source"], ("crm", "calendar", "both"), (m["id"], k))


class TimeTests(unittest.TestCase):
    def test_dst_boundaries(self):
        from datetime import datetime
        self.assertEqual(reconcile.et_offset_for_local(datetime(2025, 3, 8, 12)), -5)
        self.assertEqual(reconcile.et_offset_for_local(datetime(2025, 3, 9, 12)), -4)
        self.assertEqual(reconcile.et_offset_for_local(datetime(2025, 11, 2, 12)), -5)


if __name__ == "__main__":
    unittest.main()
