"""
Ingestion, normalisation and reconciliation of CRM + Calendar meeting records.

Pipeline:
  1. normalize_crm / normalize_calendar  -> clean records + data-quality flags
  2. dedupe_calendar                     -> collapse same-source duplicates
  3. match                               -> score & assign CRM <-> calendar pairs
  4. build_meeting                       -> per-field merge with provenance + conflicts

Pure standard library. All times are handled as naive "America/New_York" wall-clock
datetimes internally and serialised with an explicit UTC offset.
"""
import hashlib
import re
from datetime import date, datetime, time, timedelta

INTERNAL_DOMAIN = "firma.com"
MATCH_THRESHOLD = 50
MAX_TIME_GAP_MIN = 240  # beyond this a pair is never considered the same meeting

STOP = {"the", "a", "an", "of", "and", "with", "meeting", "call", "re"}
GENERIC_LOC = {"the", "office", "room", "restaurant", "hq", "conference", "main",
               "floor", "https", "http", "www"}
COMPANY_GENERIC = {"capital", "partners", "group", "holdings", "advisors", "investments",
                   "institutional", "wealth", "ventures", "investors", "inc", "llc"}
VIRTUAL_WORDS = ("zoom", "teams", "virtual", "meet.google", "webex", "hangouts")

STATUS_MAP = {"confirmed": "confirmed", "scheduled": "confirmed", "completed": "completed",
              "tentative": "tentative", "cancelled": "cancelled", "canceled": "cancelled"}
STATUS_RANK = {"cancelled": 4, "completed": 3, "confirmed": 2, "tentative": 1}


# ----------------------------------------------------------------------------- time
def _nth_sunday(year, month, n):
    first = date(year, month, 1)
    return date(year, month, 1 + (6 - first.weekday()) % 7 + 7 * (n - 1))


def et_offset_for_local(dt):
    """UTC offset (hours) for a naive US-Eastern wall-clock time."""
    start = datetime.combine(_nth_sunday(dt.year, 3, 2), time(2, 0))
    end = datetime.combine(_nth_sunday(dt.year, 11, 1), time(2, 0))
    return -4 if start <= dt < end else -5


def utc_to_et(dt):
    """Naive UTC datetime -> naive US-Eastern wall-clock datetime."""
    start = datetime.combine(_nth_sunday(dt.year, 3, 2), time(7, 0))
    end = datetime.combine(_nth_sunday(dt.year, 11, 1), time(6, 0))
    return dt + timedelta(hours=-4 if start <= dt < end else -5)


def iso(dt):
    if dt is None:
        return None
    return dt.strftime("%Y-%m-%dT%H:%M:%S") + f"{et_offset_for_local(dt):+03d}:00"


# ----------------------------------------------------------------------------- helpers
def tokens(s):
    return {t for t in re.findall(r"[a-z0-9]+", (s or "").lower()) if t not in STOP}


def letters(s):
    return re.sub(r"[^a-z]", "", (s or "").lower())


def name_from_email(email):
    local = email.split("@")[0]
    return " ".join(p.capitalize() for p in re.split(r"[._]", local) if p)


def is_internal(email):
    return bool(email) and email.lower().endswith("@" + INTERNAL_DOMAIN)


def derive_format(location):
    if not location:
        return None
    low = location.lower()
    return "virtual" if any(w in low for w in VIRTUAL_WORDS) else "in-person"


def location_core(loc):
    loc = re.sub(r"https?://\S+", " ", loc or "").lower()
    toks = set(re.findall(r"[a-z0-9]+", loc))
    return (toks - GENERIC_LOC) or toks


def locations_compatible(a, b):
    """Same place, possibly described with different granularity ('NYC Office' vs
    'NYC Office - 12th Floor', 'Zoom' vs 'Zoom - <url>')."""
    ca, cb = location_core(a), location_core(b)
    return ca <= cb or cb <= ca


def make_flagger(source, record_id, sink):
    def flag(code, message, severity="info"):
        sink.append({"source": source, "record": record_id, "code": code,
                     "severity": severity, "message": message})
    return flag


# ----------------------------------------------------------------------------- normalise
def normalize_crm(r):
    flags = []
    flag = make_flagger("crm", r.get("crm_id"), flags)

    # date: ISO, or malformed MM-DD/YYYY seen in the data
    raw_date, d = r.get("meeting_date"), None
    m_iso = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", raw_date or "")
    m_odd = re.fullmatch(r"(\d{2})-(\d{2})/(\d{4})", raw_date or "")
    try:
        if m_iso:
            d = date(int(m_iso[1]), int(m_iso[2]), int(m_iso[3]))
        elif m_odd:
            d = date(int(m_odd[3]), int(m_odd[1]), int(m_odd[2]))
            flag("malformed_date", f"meeting_date '{raw_date}' is not ISO; parsed as MM-DD/YYYY -> {d}", "warning")
    except ValueError:
        d = None
    if d is None:
        flag("invalid_date", f"meeting_date '{raw_date}' could not be parsed; record cannot be matched", "error")

    t, raw_time = None, r.get("meeting_time")
    m_t = re.fullmatch(r"(\d{1,2}):(\d{2})", raw_time or "")
    if m_t:
        t = time(int(m_t[1]), int(m_t[2]))
    else:
        flag("missing_time", "meeting_time is missing; time will be filled from the calendar if a match exists", "warning")

    mtype = (r.get("meeting_type") or "").strip()
    fmt = {"in-person": "in-person", "virtual": "virtual"}.get(mtype.lower())
    client_name = r.get("client_name")
    is_group = bool(client_name) and client_name.lower() in ("multiple", "various")
    notes = (r.get("notes") or "").strip() or None
    if notes is None:
        flag("empty_notes", "notes is empty")
    if not r.get("location") and fmt == "in-person":
        flag("missing_location", "in-person meeting without a location")
    status_raw = r.get("status") or ""
    return {
        "src": "crm", "id": r["crm_id"], "raw": r, "flags": flags,
        "subject": r.get("subject"),
        "client_name": None if is_group else client_name,
        "client_label": client_name, "is_group": is_group,
        "company": r.get("client_company"),
        "owner": r.get("relationship_owner"),
        "start": datetime.combine(d, t or time(0, 0)) if d else None,
        "time_known": t is not None,
        "category": "internal" if mtype.lower() == "internal" or not client_name else "client",
        "format": fmt, "location": r.get("location") or None, "notes": notes,
        "status_raw": status_raw, "status": STATUS_MAP.get(status_raw.lower()),
    }


def _parse_cal_ts(s, flag, label):
    if not s:
        return None, False
    utc = s.endswith("Z")
    core = s[:-1] if utc else s
    try:
        dt = datetime.fromisoformat(core)
    except ValueError:
        flag("malformed_timestamp", f"{label} '{s}' could not be parsed", "error")
        return None, False
    if dt.tzinfo is not None:  # explicit offset
        dt = (dt - dt.utcoffset()).replace(tzinfo=None)
        utc = True
    if not re.search(r"\d{2}:\d{2}:\d{2}", core):
        flag("malformed_timestamp", f"{label} '{s}' is missing seconds; parsed anyway", "warning")
    if utc:
        dt = utc_to_et(dt)
        flag("utc_converted", f"{label} '{s}' is UTC; converted to US Eastern -> {dt:%Y-%m-%d %H:%M}", "info")
    return dt, utc


def normalize_calendar(r):
    flags = []
    flag = make_flagger("calendar", r.get("event_id"), flags)
    start, utc = _parse_cal_ts(r.get("start_time"), flag, "start_time")
    end, _ = _parse_cal_ts(r.get("end_time"), flag, "end_time")
    if start is None:
        flag("invalid_start", "start_time missing/invalid; record cannot be matched", "error")

    attendees = []
    for raw in r.get("attendees") or []:
        fixed = raw.replace("[at]", "@").replace("(at)", "@").strip()
        valid = bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", fixed))
        if valid and fixed != raw:
            flag("repaired_attendee", f"attendee '{raw}' was malformed; repaired to '{fixed}'", "warning")
        elif not valid:
            flag("placeholder_attendee", f"attendee '{raw}' is not an email address (placeholder); kept but not treated as a person", "warning")
        attendees.append({"email": fixed.lower() if valid else None,
                          "name": name_from_email(fixed) if valid else raw,
                          "valid": valid, "sources": ["calendar"],
                          "repaired": valid and fixed != raw, "raw": raw})
    if not attendees:
        flag("no_attendees", "attendee list is empty", "warning")
    if not r.get("location"):
        flag("missing_location", "location is null")
    org = (r.get("organizer") or "").lower()
    return {
        "src": "calendar", "id": r["event_id"], "raw": r, "flags": flags,
        "title": r.get("title"), "organizer_email": org,
        "organizer": name_from_email(org) if org else None,
        "attendees": attendees, "start": start, "end": end, "utc": utc,
        "location": r.get("location") or None,
        "description": r.get("description") or None,
        "is_recurring": bool(r.get("is_recurring")),
        "status_raw": r.get("status") or "",
        "status": STATUS_MAP.get((r.get("status") or "").lower()),
        "created_at": r.get("created_at") or "",
    }


# ----------------------------------------------------------------------------- dedupe
def _ext_keys(rec):
    return {a["email"] for a in rec["attendees"] if a["valid"] and not is_internal(a["email"])}


def _is_dup(a, b):
    if a["is_recurring"] or b["is_recurring"] or not a["start"] or not b["start"]:
        return False
    if a["organizer_email"] != b["organizer_email"] or a["start"].date() != b["start"].date():
        return False
    if not (_ext_keys(a) & _ext_keys(b)):
        return False
    return a["start"] < (b["end"] or b["start"]) and b["start"] < (a["end"] or a["start"])


def dedupe_calendar(records):
    """Group same-organizer, same-day, time-overlapping events that share an external
    attendee. Earliest-created record is canonical."""
    entities = []
    for rec in sorted(records, key=lambda x: x["created_at"]):
        for ent in entities:
            if any(_is_dup(m, rec) for m in ent["members"]):
                ent["members"].append(rec)
                break
        else:
            entities.append({"members": [rec]})
    for ent in entities:
        ent["canonical"] = ent["members"][0]
        merged, seen = [], {}
        for m in ent["members"]:
            for a in m["attendees"]:
                key = a["email"] or a["raw"].lower()
                if key not in seen:
                    seen[key] = dict(a, sources=["calendar"])
                    merged.append(seen[key])
        ent["attendees"] = merged
    return entities


# ----------------------------------------------------------------------------- matching
def _company_sig(company):
    return [t for t in tokens(company) if t not in COMPANY_GENERIC]


def score_pair(c, ent):
    k = ent["canonical"]
    if not c["start"] or not k["start"] or c["start"].date() != k["start"].date():
        return 0, []
    pts, why = 0, []
    ext = [a for a in ent["attendees"] if a["valid"] and not is_internal(a["email"])]

    # who: strongest signals
    if c["client_name"] and any(letters(a["email"].split("@")[0]) == letters(c["client_name"]) for a in ext):
        pts += 50
        why.append(f"client '{c['client_name']}' is an attendee")
    sig = _company_sig(c["company"])
    blob = tokens(" ".join(m["title"] or "" for m in ent["members"]) + " " +
                  " ".join(m["description"] or "" for m in ent["members"]))
    domains = [a["email"].split("@")[1].split(".")[0] for a in ext]
    if sig and (all(t in blob for t in sig) or
                any(len(sig[0]) >= 4 and d.startswith(sig[0]) for d in domains)):
        pts += 30
        why.append(f"company '{c['company']}' matches attendee domain/title")
    internal_only = (ent["attendees"] and not ext and
                     all(a["valid"] and is_internal(a["email"]) for a in ent["attendees"]))
    if c["category"] == "internal" and internal_only:
        pts += 25
        why.append("both are internal-only meetings")

    # when
    if c["time_known"]:
        diff = min(abs((c["start"] - m["start"]).total_seconds()) / 60 for m in ent["members"] if m["start"])
        if diff > MAX_TIME_GAP_MIN:
            return 0, []
        gain = 30 if diff == 0 else 25 if diff <= 30 else 15 if diff <= 90 else 5
        pts += gain
        why.append("same start time" if diff == 0 else f"start times {int(diff)} min apart")
    else:
        pts += 10
        why.append("CRM has no time; same date only")

    # what / whose
    ct = tokens(c["subject"])
    best = max((len(ct & tokens(m["title"])) / max(1, min(len(ct), len(tokens(m["title"]))))
                for m in ent["members"]), default=0)
    if best:
        pts += round(20 * best)
        why.append(f"title word overlap {best:.0%}")
    owner = letters(c["owner"])
    if owner and any(letters(m["organizer"]) == owner for m in ent["members"]):
        pts += 10
        why.append("owner is the calendar organizer")
    elif owner and any(letters(a["name"]) == owner for a in ent["attendees"] if a["valid"]):
        pts += 5
        why.append("owner is an attendee")
    return pts, why


def match(crm_recs, entities):
    cands = []
    for ci, c in enumerate(crm_recs):
        for ei, e in enumerate(entities):
            s, why = score_pair(c, e)
            if s >= MATCH_THRESHOLD:
                cands.append((s, ci, ei, why))
    cands.sort(key=lambda x: -x[0])
    used_c, used_e, pairs = set(), set(), {}
    for s, ci, ei, why in cands:
        if ci in used_c or ei in used_e:
            continue
        used_c.add(ci)
        used_e.add(ei)
        pairs[ci] = (ei, s, why)
    return pairs


# ----------------------------------------------------------------------------- merge
def _field(value, source, alternatives=None, conflict=False, note=None):
    return {"value": value, "source": source, "alternatives": alternatives or [],
            "conflict": conflict, "note": note}


def _fmt_range(start, end):
    if not start:
        return None
    s = start.strftime("%Y-%m-%d %H:%M")
    return f"{s}-{end:%H:%M}" if end else s


def build_meeting(c, ent):
    cal = ent["canonical"] if ent else None
    f, conflicts, flags = {}, [], []
    sources = (["crm"] if c else []) + (["calendar"] if cal else [])
    if c:
        flags += c["flags"]
    if ent:
        for m in ent["members"]:
            flags += m["flags"]

    def conflict(field, severity, values, resolution, reason):
        conflicts.append({"field": field, "severity": severity, "values": values,
                          "resolution": resolution, "reason": reason})
        if field in f:
            f[field]["conflict"] = True

    # --- title
    if cal:
        alts = [{"source": "crm", "value": c["subject"]}] if c and c["subject"] != cal["title"] else []
        f["title"] = _field(cal["title"], "calendar", alts)
    else:
        f["title"] = _field(c["subject"], "crm")

    # --- start / end
    if cal:
        note = None
        alts = []
        if c and c["time_known"]:
            diff = int((cal["start"] - c["start"]).total_seconds() // 60)
            if diff != 0:
                alts = [{"source": "crm", "value": _fmt_range(c["start"], None)}]
                hint = ""
                if cal["utc"] and abs(diff) == 60:
                    hint = (" Calendar stores UTC; converting with the real US-Eastern offset for that date "
                            "(DST began 2025-03-09) gives a 1h difference from the CRM wall-clock time - "
                            "likely an offset applied at creation time. Verify with the owner.")
                f["start"] = _field(iso(cal["start"]), "calendar", alts)
                conflict("start", "high" if abs(diff) > 60 else "warning",
                         {"crm": _fmt_range(c["start"], None), "calendar": _fmt_range(cal["start"], cal["end"])},
                         "calendar time used (carries end time, timezone and invite)",
                         f"Start times differ by {abs(diff)} min.{hint}")
        elif c and not c["time_known"]:
            note = "CRM time missing - filled from calendar"
        if "start" not in f:
            f["start"] = _field(iso(cal["start"]), "calendar", alts, note=note)
        f["end"] = _field(iso(cal["end"]), "calendar")
        if len(ent["members"]) > 1:
            f["start"]["alternatives"] += [{"source": "calendar", "value": f"{m['id']}: {_fmt_range(m['start'], m['end'])}"}
                                           for m in ent["members"][1:]]
    else:
        f["start"] = _field(iso(c["start"]) if c["time_known"] else (c["start"].strftime("%Y-%m-%d") if c["start"] else None),
                            "crm", note=None if c["time_known"] else "time unknown")
        f["end"] = _field(None, "crm", note="CRM has no end time")

    # --- location (+ meeting format)
    cal_locs = [m["location"] for m in ent["members"] if m["location"]] if ent else []
    cal_loc = max(cal_locs, key=len) if cal_locs else None
    crm_loc = c["location"] if c else None
    cal_fmt = derive_format(cal_loc)
    if cal_loc and crm_loc:
        if locations_compatible(cal_loc, crm_loc):
            # same place - keep the more specific text, show the other as an alternative
            pick_cal = len(cal_loc) >= len(crm_loc)
            val, src = (cal_loc, "calendar") if pick_cal else (crm_loc, "crm")
            other = (crm_loc, "crm") if pick_cal else (cal_loc, "calendar")
            alts = [] if other[0] == val else [{"source": other[1], "value": other[0]}]
            f["location"] = _field(val, src, alts, note="same place, different wording" if alts else None)
        else:
            f["location"] = _field(cal_loc, "calendar", [{"source": "crm", "value": crm_loc}])
            conflict("location", "high", {"crm": crm_loc, "calendar": cal_loc},
                     "calendar location used (it is what invitees received)",
                     "Locations refer to different places/formats.")
    elif cal_loc or crm_loc:
        f["location"] = _field(cal_loc or crm_loc, "calendar" if cal_loc else "crm",
                               note="only one source has a location" if c and cal else None)
    else:
        f["location"] = _field(None, sources[0], note="no location in any source")

    crm_fmt = c["format"] if c else None
    if crm_fmt and cal_fmt:
        if crm_fmt != cal_fmt:
            f["format"] = _field(cal_fmt, "calendar", [{"source": "crm", "value": crm_fmt}])
            conflict("format", "high", {"crm": crm_fmt, "calendar": f"{cal_fmt} (from '{cal_loc}')"},
                     "calendar-derived format used",
                     "CRM meeting_type disagrees with the calendar location "
                     f"(CRM says {crm_fmt}, calendar location implies {cal_fmt}).")
        else:
            f["format"] = _field(cal_fmt, "both")
    elif crm_fmt or cal_fmt:
        f["format"] = _field(crm_fmt or cal_fmt, "crm" if crm_fmt else "calendar")
    else:
        f["format"] = _field(derive_format(f["location"]["value"]), f["location"]["source"],
                             note="derived from location")

    # --- status
    if c and cal:
        cs, ks = c["status"], cal["status"]
        grp = lambda s: "cancelled" if s == "cancelled" else "tentative" if s == "tentative" else "active"
        winner = max([cs, ks], key=lambda s: STATUS_RANK.get(s, 0))
        src = "crm" if winner == cs and winner != ks else "calendar" if winner == ks and winner != cs else "both"
        f["status"] = _field(winner, src, [{"source": "crm", "value": c["status_raw"]},
                                           {"source": "calendar", "value": cal["status_raw"]}]
                             if (c["status_raw"].lower() != cal["status_raw"].lower()) else [])
        if grp(cs) != grp(ks):
            sev = "high" if "cancelled" in (cs, ks) else "warning"
            conflict("status", sev, {"crm": c["status_raw"], "calendar": cal["status_raw"]},
                     f"'{winner}' used (cancellation > completion > confirmation > tentative)",
                     "Sources disagree on whether the meeting is happening. Cancellations are treated as "
                     "authoritative because calendars are commonly not updated; needs human confirmation.")
    else:
        rec = c or cal
        f["status"] = _field(rec["status"], rec["src"], note=None if rec["status"] else "unmapped status")

    # --- ownership / organizer
    org_name = cal["organizer"] if cal else None
    if c and cal and letters(c["owner"]) != letters(org_name):
        f["owner"] = _field(c["owner"], "crm", [{"source": "calendar", "value": f"{org_name} (organizer)"}])
        conflict("owner", "info", {"crm": c["owner"], "calendar": f"{org_name} (organizer)"},
                 "CRM relationship owner kept as owner; organizer shown separately",
                 "Different roles (relationship owner vs. invite organizer) - not necessarily an error.")
    else:
        f["owner"] = _field(c["owner"] if c else org_name, "both" if c and cal else ("crm" if c else "calendar"))
    f["organizer"] = _field(org_name, "calendar" if cal else "crm", note=None if cal else "no calendar record")

    # --- attendees
    atts = [dict(a) for a in (ent["attendees"] if ent else [])]
    if c and c["client_name"]:
        hit = next((a for a in atts if a["valid"] and letters(a["email"].split("@")[0]) == letters(c["client_name"])), None)
        if hit:
            hit["name"] = c["client_name"]
            hit["sources"] = ["calendar", "crm"]
        else:
            atts.append({"email": None, "name": c["client_name"], "valid": False,
                         "sources": ["crm"], "repaired": False, "raw": c["client_name"]})
    f["attendees"] = _field(atts, "both" if c and cal else sources[0])
    if c and cal:
        m_cnt = re.search(r"(\d+)\s+attendees", c["notes"] or "")
        if m_cnt and int(m_cnt[1]) != len(atts):
            flags.append({"source": "crm", "record": c["id"], "code": "attendee_count_mismatch", "severity": "info",
                          "message": f"CRM notes say {m_cnt[1]} attendees; calendar lists {len(ent['attendees'])} "
                                     "entries (including placeholders)"})

    # --- client
    if c and (c["client_name"] or c["company"]):
        f["client"] = _field({"name": c["client_label"], "company": c["company"]}, "crm")
    else:
        ext = [a for a in f["attendees"]["value"] if a["valid"] and not is_internal(a["email"])]
        f["client"] = _field({"name": ext[0]["name"], "company": None} if ext else None,
                             "calendar" if ext else (sources[0]),
                             note="derived from external attendee" if ext else "internal meeting / no client")

    # --- notes
    c_notes = c["notes"] if c else None
    k_notes = cal["description"] if cal else None
    if c_notes and k_notes:
        f["notes"] = _field(c_notes, "crm", [{"source": "calendar", "value": k_notes}], note="both sources have notes")
    else:
        f["notes"] = _field(c_notes or k_notes, "crm" if c_notes else "calendar" if k_notes else sources[0])

    # --- duplicates collapsed within the calendar
    if ent and len(ent["members"]) > 1:
        vals = {m["id"]: f"{m['title']} | {_fmt_range(m['start'], m['end'])} | {m['location'] or 'no location'}"
                for m in ent["members"]}
        conflict("calendar_duplicate", "warning", vals,
                 f"merged into one meeting; {ent['canonical']['id']} (earliest created) is canonical, "
                 "attendees unioned, most specific location kept",
                 "Same organizer, same day, overlapping time and shared external attendee - treated as one meeting "
                 "entered twice (or re-entered after a reschedule). The time difference is listed under 'start'.")

    category = c["category"] if c else (
        None if not cal["attendees"] else
        "internal" if all(a["valid"] and is_internal(a["email"]) for a in cal["attendees"]) else "client")
    ids = sorted(([c["id"]] if c else []) + ([m["id"] for m in ent["members"]] if ent else []))
    return {
        "id": "mtg-" + hashlib.sha1("|".join(ids).encode()).hexdigest()[:8],
        "title": f["title"]["value"],
        "start": f["start"]["value"], "end": f["end"]["value"],
        "status": f["status"]["value"], "format": f["format"]["value"],
        "location": f["location"]["value"], "category": category,
        "is_recurring": bool(cal and cal["is_recurring"]),
        "sources": sources,
        "source_records": {"crm": c["id"] if c else None,
                           "calendar": [m["id"] for m in ent["members"]] if ent else []},
        "fields": f, "conflicts": conflicts, "quality_flags": flags,
        "max_severity": max((x["severity"] for x in conflicts),
                            key=lambda s: ["info", "warning", "high"].index(s), default=None),
        "_raw": {"crm": c["raw"] if c else None,
                 "calendar": [m["raw"] for m in ent["members"]] if ent else []},
    }


# ----------------------------------------------------------------------------- orchestrate
def reconcile(crm_raw, cal_raw):
    crm = [normalize_crm(r) for r in crm_raw]
    cal = [normalize_calendar(r) for r in cal_raw]
    entities = dedupe_calendar(cal)
    pairs = match(crm, entities)

    meetings, matched_e = [], set()
    for ci, c in enumerate(crm):
        if ci in pairs:
            ei, score, why = pairs[ci]
            matched_e.add(ei)
            m = build_meeting(c, entities[ei])
            m["match"] = {"score": score, "reasons": why}
        else:
            m = build_meeting(c, None)
            m["match"] = None
        meetings.append(m)
    for ei, e in enumerate(entities):
        if ei not in matched_e:
            m = build_meeting(None, e)
            m["match"] = None
            meetings.append(m)

    # CRM note says "rescheduled to M/D" -> is there a plausible replacement meeting?
    for m in meetings:
        crm_id = m["source_records"]["crm"]
        note = m["fields"]["notes"]["value"] or ""
        r = re.search(r"reschedul\w*\s+to\s+(\d{1,2})/(\d{1,2})", note, re.I)
        if m["status"] == "cancelled" and r and m["start"]:
            mo, dy = int(r[1]), int(r[2])
            tt = tokens(m["title"])
            found = any(o is not m and o["start"] and int(o["start"][5:7]) == mo and int(o["start"][8:10]) == dy
                        and tokens(o["title"]) & tt for o in meetings)
            if not found:
                m["quality_flags"].append({
                    "source": "crm", "record": crm_id, "code": "reschedule_not_found", "severity": "warning",
                    "message": f"CRM notes say the meeting was rescheduled to {mo}/{dy}, but no similar meeting "
                               f"exists on that date in either source."})

    meetings.sort(key=lambda m: (m["start"] or "9999", m["title"] or ""))
    flags = [fl for m in meetings for fl in m["quality_flags"]]
    stats = {
        "crm_records": len(crm), "calendar_records": len(cal),
        "meetings": len(meetings),
        "in_both": sum(1 for m in meetings if len(m["sources"]) == 2),
        "crm_only": sum(1 for m in meetings if m["sources"] == ["crm"]),
        "calendar_only": sum(1 for m in meetings if m["sources"] == ["calendar"]),
        "calendar_duplicates_merged": sum(len(e["members"]) - 1 for e in entities),
        "with_conflicts": sum(1 for m in meetings if any(x["severity"] != "info" for x in m["conflicts"])),
        "conflicts_by_severity": {s: sum(1 for m in meetings for x in m["conflicts"] if x["severity"] == s)
                                  for s in ("high", "warning", "info")},
        "quality_flags": len(flags),
    }
    return {"meetings": meetings, "stats": stats, "quality_flags": flags}
