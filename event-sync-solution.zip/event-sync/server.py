#!/usr/bin/env python3
"""Event Sync Service - REST API + static frontend. Standard library only.

    python3 server.py            # http://localhost:8000
    PORT=9000 python3 server.py
"""
import json
import mimetypes
import os
import sys
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import reconcile

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("DATA_DIR", os.path.join(ROOT, "data"))
STATIC_DIR = os.path.join(ROOT, "static")

_lock = threading.Lock()
STATE = {"result": None, "synced_at": None, "error": None}


def ingest():
    """(Re)read both source files and rebuild the reconciled view."""
    try:
        with open(os.path.join(DATA_DIR, "crm_events.json"), encoding="utf-8") as fh:
            crm = json.load(fh)
        with open(os.path.join(DATA_DIR, "calendar_events.json"), encoding="utf-8") as fh:
            cal = json.load(fh)
        result = reconcile.reconcile(crm, cal)
        with _lock:
            STATE.update(result=result, synced_at=datetime.now(timezone.utc).isoformat(), error=None)
    except (OSError, ValueError, KeyError) as exc:  # keep serving last good data
        with _lock:
            STATE["error"] = f"{type(exc).__name__}: {exc}"
        raise


def public(m, detail=False):
    out = {k: v for k, v in m.items() if k != "_raw"}
    if detail:
        out["raw_records"] = m["_raw"]
    return out


def filter_meetings(meetings, q):
    def one(name):
        return (q.get(name) or [""])[0].strip()

    src, status, sev, text = one("source"), one("status"), one("severity"), one("q").lower()
    only_conf = one("has_conflicts").lower() in ("1", "true", "yes")
    frm, to = one("from"), one("to")
    out = []
    for m in meetings:
        if src == "both" and len(m["sources"]) != 2:
            continue
        if src in ("crm", "calendar") and m["sources"] != [src]:
            continue
        if status and m["status"] != status:
            continue
        if only_conf and not any(c["severity"] != "info" for c in m["conflicts"]):
            continue
        if sev and not any(c["severity"] == sev for c in m["conflicts"]):
            continue
        if frm and (m["start"] or "")[:10] < frm:
            continue
        if to and (m["start"] or "")[:10] > to:
            continue
        if text:
            hay = " ".join([m["title"] or "", m["location"] or "", json.dumps(m["fields"]["client"]["value"]),
                            m["fields"]["owner"]["value"] or "",
                            " ".join(a["name"] or "" for a in m["fields"]["attendees"]["value"])]).lower()
            if text not in hay:
                continue
        out.append(m)
    return out


class Handler(BaseHTTPRequestHandler):
    server_version = "EventSync/1.0"

    def _json(self, obj, status=200):
        body = json.dumps(obj, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urlparse(self.path)
        path = url.path.rstrip("/") or "/"
        if path.startswith("/api/"):
            return self.api_get(path, parse_qs(url.query))
        return self.static(path)

    def do_POST(self):
        if urlparse(self.path).path.rstrip("/") == "/api/sync":
            try:
                ingest()
            except Exception as exc:
                return self._json({"error": str(exc)}, 500)
            return self._json({"synced_at": STATE["synced_at"], "stats": STATE["result"]["stats"]})
        self._json({"error": "not found"}, 404)

    def api_get(self, path, q):
        res = STATE["result"]
        if path == "/api/health":
            return self._json({"status": "ok" if res else "no data", "synced_at": STATE["synced_at"],
                               "last_error": STATE["error"]})
        if res is None:
            return self._json({"error": STATE["error"] or "not ingested yet"}, 503)
        if path == "/api/meetings":
            items = filter_meetings(res["meetings"], q)
            return self._json({"count": len(items), "synced_at": STATE["synced_at"],
                               "meetings": [public(m) for m in items]})
        if path.startswith("/api/meetings/"):
            mid = path.rsplit("/", 1)[1]
            m = next((x for x in res["meetings"] if x["id"] == mid), None)
            return self._json(public(m, True)) if m else self._json({"error": "meeting not found"}, 404)
        if path == "/api/stats":
            return self._json(dict(res["stats"], synced_at=STATE["synced_at"]))
        if path == "/api/quality":
            return self._json({"count": len(res["quality_flags"]), "flags": res["quality_flags"]})
        self._json({"error": "not found"}, 404)

    def static(self, path):
        rel = "index.html" if path == "/" else path.lstrip("/")
        full = os.path.realpath(os.path.join(STATIC_DIR, rel))
        if not full.startswith(os.path.realpath(STATIC_DIR) + os.sep) or not os.path.isfile(full):
            return self._json({"error": "not found"}, 404)
        with open(full, "rb") as fh:
            body = fh.read()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(full)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))


def main():
    ingest()
    s = STATE["result"]["stats"]
    print(f"Ingested {s['crm_records']} CRM + {s['calendar_records']} calendar records "
          f"-> {s['meetings']} meetings ({s['in_both']} in both, {s['crm_only']} CRM-only, "
          f"{s['calendar_only']} calendar-only, {s['calendar_duplicates_merged']} duplicate merged)")
    port = int(os.environ.get("PORT", "8000"))
    httpd = ThreadingHTTPServer((os.environ.get("HOST", "127.0.0.1"), port), Handler)
    print(f"Serving on http://localhost:{port}  (Ctrl+C to stop)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")


if __name__ == "__main__":
    main()
