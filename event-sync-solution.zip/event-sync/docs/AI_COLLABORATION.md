# AI collaboration notes

The brief encourages AI use with transparency. This documents how it was used. **Edit this to reflect your own actual process before submitting** - it is a starting point, not a record of what you personally did.

## Workflow
1. Gave the assistant the problem statement and both JSON files.
2. Asked for an audit of every anomaly in the data *before* choosing an architecture.
3. Agreed on the design below, had the assistant implement it, then reviewed the output against the data by hand.
4. Verified with tests and by running the server (`curl` against each endpoint).

## 1. Data audit (brainstorm)

| # | Observation | Records |
|---|---|---|
| 1 | No shared id; join must be inferred | all |
| 2 | Mixed timestamps: naive local vs UTC `Z`; UTC example is 1 h off CRM once DST is applied | CAL-A4 / CRM-1004 |
| 3 | Malformed CRM date `03-15/2025` | CRM-1008 |
| 4 | Malformed calendar end time (no seconds) | CAL-A11 |
| 5 | Malformed attendee `[at]`; placeholder attendee | CAL-A16, CAL-A20 |
| 6 | Null time / location / client; empty notes | CRM-1007, 1003, 1014, CAL-A11, A15 |
| 7 | Same-source duplicate in calendar | CAL-A5 / A6 |
| 8 | Format conflict (Zoom vs In-Person) | CAL-A2 / CRM-1002 |
| 9 | Status conflict (Cancelled vs confirmed), note says "rescheduled to 3/26" but no such meeting exists | CRM-1009 / CAL-A10 |
| 10 | 2 h time disagreement | CRM-1016 / CAL-A17 |
| 11 | Look-alikes that must NOT merge: recurring instances A3/A18; two Meridian meetings (3/10 vs 3/18); two Atlas meetings; two Crestview meetings | - |
| 12 | Owner vs organizer differ; attendee count mismatch (12 vs 6) | CRM-1013, CRM-1017 |
| 13 | Calendar-only/CRM-only meetings that legitimately have no counterpart | CRM-1003/1010/1020, CAL-A3/A11/A18/A19 |

## 2. Options considered

- **Exact-key join** (date+time+title): rejected - titles differ in almost every pair, and times differ in some real matches.
- **String-similarity library** (rapidfuzz etc.): rejected - adds a dependency and is opaque. Names/emails/companies give much stronger, explainable signals than title text.
- **Additive score + threshold + 1:1 assignment** (chosen): explainable, tunable, no single weak signal can create a match.
- **Storage:** DB vs in-memory. In-memory chosen; two tiny files.
- **Stack:** Python stdlib so the reviewer needs nothing installed.

## 3. Plan
1. `reconcile.py`: normalise -> dedupe -> match -> merge, each step a pure function.
2. Provenance as data: every merged field carries `source`, `alternatives`, `conflict`, `note`.
3. `server.py`: REST API + static hosting.
4. `static/index.html`: list + expandable provenance view.
5. Tests that pin the specific tricky cases above.
6. README: approach, rules table, assumptions, limitations.

## 4. Human review checklist (do this yourself)
- [ ] Do you agree with "calendar wins on logistics, CRM on relationships"?
- [ ] Do you agree with the US-Eastern assumption for naive timestamps?
- [ ] Is "cancelled wins" the right default for CRM-1009?
- [ ] Update the "Time spent" section in the README.
