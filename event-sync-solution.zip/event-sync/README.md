# Event Sync Service

Ingests a CRM export and a Calendar export, works out which records describe the **same real-world meeting**, merges them field by field, and serves the result through a REST API and a small web UI that shows **where every value came from and where the sources disagree**.

- **Language:** Python 3.8+ (tested on 3.12). **Zero third-party dependencies**, nothing to `pip install`.
- **Frontend:** one static HTML file with vanilla JS, served by the same process.

## Run it

```bash
cd event-sync
python3 server.py
# -> http://localhost:8000
```

Options: `PORT=9000 python3 server.py`, `HOST=0.0.0.0 ...`, `DATA_DIR=/other/folder ...`.
Data files live in `data/` (`crm_events.json`, `calendar_events.json`). Edit them and click **Re-sync** in the UI (or `POST /api/sync`) to re-ingest without restarting.

Run the tests:

```bash
python3 -m unittest discover -s tests -v
```

## Using the UI

- One row per reconciled meeting. The **Sources** badge shows CRM / Calendar / Both; **Issues** shows conflicts and data problems.
- Click a row to open the provenance view: for every field you see the reconciled value, which source it came from, what the other source said, and any conflict (highlighted) with the rule used to resolve it. It also lists data-quality flags and the raw source records.
- Filters: text search, source (both / CRM only / calendar only), status, "only meetings with conflicts".
- All times are displayed in US Eastern (see assumptions).

## REST API

| Method & path | Description |
|---|---|
| `GET /api/meetings` | Reconciled list. Query: `source=both\|crm\|calendar`, `status=`, `has_conflicts=true`, `severity=high\|warning\|info`, `q=` (text), `from=YYYY-MM-DD`, `to=YYYY-MM-DD` |
| `GET /api/meetings/{id}` | One meeting incl. per-field provenance, conflicts, flags and `raw_records` |
| `GET /api/stats` | Counts (meetings, in both, single-source, conflicts by severity...) |
| `GET /api/quality` | Flat list of every data-quality flag (malformed/missing data and what was done) |
| `POST /api/sync` | Re-read the data files and rebuild |
| `GET /api/health` | Liveness + last sync time/error |

Each meeting looks like:

```jsonc
{
  "id": "mtg-1a2b3c4d",                 // stable hash of the source record ids
  "title": "...", "start": "2025-03-13T15:00:00-04:00", "status": "confirmed",
  "sources": ["crm", "calendar"],
  "source_records": {"crm": "CRM-1004", "calendar": ["CAL-A4"]},
  "fields": {                           // provenance for every field
    "start": {"value": "...", "source": "calendar", "alternatives": [{"source": "crm", "value": "..."}],
              "conflict": true, "note": null},
    "...": {}
  },
  "conflicts": [{"field": "start", "severity": "warning", "values": {"crm": "...", "calendar": "..."},
                 "resolution": "...", "reason": "..."}],
  "quality_flags": [{"source": "calendar", "record": "CAL-A4", "code": "utc_converted", "severity": "info", "message": "..."}],
  "match": {"score": 105, "reasons": ["client 'Patricia Langley' is an attendee", "..."]}
}
```

## Approach

```
crm_events.json ──► normalize_crm ──────────────┐
                                                ├─► match (score + 1:1 assignment) ─► build_meeting ─► API / UI
calendar_events.json ─► normalize_calendar ─► dedupe_calendar ┘
```

All logic is in `reconcile.py` (pure functions, no I/O); `server.py` is a thin HTTP layer.

### 1. Normalise (and flag, never silently fix)
Every repair emits a **quality flag** that is visible in the UI/API.

| Problem in the data | Handling |
|---|---|
| CRM date `03-15/2025` (CRM-1008) | Parsed as MM-DD/YYYY, flagged |
| Calendar `end_time` `2025-03-14T20:00` with no seconds (CAL-A11) | Parsed, flagged |
| Calendar timestamps mixed: naive local vs `...Z` UTC (CAL-A4) | UTC converted to US Eastern using the real DST rule for that date |
| Attendee `raj.patel[at]atlasvc.com` (CAL-A16) | Repaired to a real email, flagged |
| Attendee `external-guests` (CAL-A20) | Kept but marked as a placeholder, not a person |
| CRM `meeting_time` null (CRM-1007) | Date-only matching; time filled from calendar, noted |
| CRM `client_name: "Multiple"` (CRM-1017) | Treated as a group, not a person |
| `location`/`notes` null or empty, empty attendee list (CAL-A11) | Normalised to null, flagged where it matters |

### 2. Same-source duplicate
`CAL-A5` ("Investor Update - Pinnacle", 11:00) and `CAL-A6` ("Pinnacle Group - Q1 Update", 11:30) have the same organizer, same day, overlapping time and the same external attendee, so they are collapsed into **one** meeting. The earliest-created record is canonical (and it agrees with the CRM time), attendees are unioned (this adds Sandra Mills, which the CRM note "Kevin may bring CIO" corroborates), the more specific location is kept, and a `calendar_duplicate` conflict records both versions including the 30-minute time disagreement.
Recurring instances (`CAL-A3` and `CAL-A18`, same series, different weeks) are deliberately **not** merged: the dedupe rule excludes recurring events and requires same-day overlap.

### 3. Match CRM ↔ Calendar
There is no shared ID, so each candidate pair (same local date, start times within 4 h) gets an additive score, and pairs ≥ 50 are assigned greedily best-first, one-to-one:

| Signal | Points |
|---|---|
| CRM client name equals an external attendee (`David Park` ↔ `david.park@...`) | 50 |
| CRM company matches attendee email domain, or its distinctive words are in the title/description | 30 |
| Both internal-only (CRM "Internal" + all attendees `@firma.com`) | 25 |
| Start-time proximity: exact 30 / ≤30 min 25 / ≤90 min 15 / ≤4 h 5 / unknown 10 | 0–30 |
| Title word overlap | 0–20 |
| CRM owner is the calendar organizer (+10) or an attendee (+5) | 5–10 |

Date is a hard requirement. No single weak signal can create a match (threshold 50), so "Client Reception" (CAL-A11) is not forced onto an unrelated CRM row. The `match` object on each meeting records the score and the reasons, so every pairing is explainable.

**Result on the provided data:** 20 CRM + 22 calendar records → **24 meetings**: 17 in both, 3 CRM-only (CRM-1003, 1010, 1020), 4 calendar-only (CAL-A3, A18, A11, A19).

### 4. Merge with per-field rules

| Field | Rule |
|---|---|
| Start / end | **Calendar wins** (has end time, timezone, the actual invite). A CRM-vs-calendar difference is a conflict (warning ≤ 60 min, high above) |
| Location | If one is a refinement of the other (`NYC Office` vs `NYC Office - 12th Floor`, `Zoom` vs `Zoom - <url>`) → **not** a conflict, most specific text kept, the other shown as "also reported as". Otherwise **conflict**, calendar wins |
| Format (in-person/virtual) | CRM `meeting_type` compared with the format implied by the calendar location (zoom/teams/virtual). Mismatch = high conflict, calendar wins |
| Status | `cancelled > completed > confirmed > tentative`. CRM "Scheduled" is treated as confirmed. `Completed` vs `confirmed` is *not* a conflict. A cancelled-vs-active mismatch is a **high** conflict needing a human |
| Owner | CRM relationship owner. If the calendar organizer is someone else, an **info** note (different roles, not an error). Organizer is also shown as its own field |
| Client | CRM; for calendar-only meetings derived from external attendees |
| Title / notes | Both kept; calendar title and CRM notes shown first, the other as an alternative. Wording differences are not conflicts |
| Attendees | Union (calendar emails + CRM client), each tagged with the sources that list it |

The guiding idea: **never drop information and never hide a disagreement.** A resolved value is always accompanied by the losing value and the reason.

## Conflicts found in the provided data

| Meeting | Finding | Resolution |
|---|---|---|
| Summit Advisors (CRM-1002 / CAL-A2) | CRM: In-Person at NYC Office; calendar: Zoom link | High: format + location. Calendar used (it's what invitees received) |
| Board Prep (CRM-1009 / CAL-A10) | CRM: **Cancelled** ("rescheduled to 3/26"); calendar: confirmed | High: shown as cancelled. Extra flag: nothing resembling a board-prep meeting exists on 3/26 in either system |
| ESG review (CRM-1016 / CAL-A17) | CRM 13:00 vs calendar 15:00 | High: 2 h apart; calendar used |
| Crestview DD (CRM-1004 / CAL-A4) | CRM 14:00 vs calendar `19:00Z` = 15:00 EDT | Warning: exactly 1 h off, consistent with the offset being applied as EST rather than EDT (DST began 3/9). Calendar used, flagged for verification |
| Pinnacle (CAL-A5 / A6) | Duplicate in calendar | Merged (see above) |
| LPAC Prep (CRM-1013 / CAL-A14) | Owner Sarah vs organizer Priya | Info only |
| Closing Dinner (CRM-1017 / CAL-A20) | CRM says 12 attendees, calendar lists 6 entries incl. placeholder | Info flag |

## Key decisions & assumptions

1. **Naive timestamps are US Eastern.** Most calendar entries and every CRM entry have no timezone, and the offices referenced are DC/NYC/Boston. This is one constant-time assumption in one function (`et_offset_for_local`). Outputs carry an explicit offset.
2. **Calendar is the source of truth for logistics (when/where/how), CRM for relationships (client, owner, notes).** This is a policy, not a fact, and it's isolated in `build_meeting`. Because losing values are retained, changing the policy doesn't lose data.
3. **Heuristic matching over exact keys, with an explainable score.** Chosen over fuzzy-string libraries to keep it dependency-free and debuggable. The threshold and weights are constants at the top of the module.
4. **Surface, don't silently resolve, where a wrong guess is costly** (cancelled vs confirmed, 2 h time gap, 1 h DST gap): pick a sensible default but mark it high/warning.
5. **Ingest on startup, in memory, with an explicit re-sync.** The dataset is two small files; a database would add moving parts without value. On a failed re-sync the last good data keeps being served and the error shows in `/api/health`.
6. **Standard-library HTTP server.** Fine for an internal tool/demo; for production I'd put the same `reconcile.py` behind FastAPI/Flask + a real store.

## Limitations / what I'd do next

- Matching assumes the CRM and calendar agree on the *date* (after timezone conversion). A meeting moved to another day in one system would show up as two single-source meetings. A wider date window with a stricter score would address this.
- Same-source duplicate detection only runs on the calendar (that's where the data has one); the function is generic enough to extend to CRM.
- Attendee names for calendar-only people are derived from email local-parts (`Kevin Obrien` rather than `Kevin O'Brien` unless the CRM supplies the real name).
- No auth, pagination, or persistence; no write-back to either system.
- Tests cover the specific scenarios in the supplied data plus DST boundaries; they are regression anchors, not exhaustive.

## Layout

```
server.py          HTTP server + REST API + static hosting
reconcile.py       normalise -> dedupe -> match -> merge (pure logic)
static/index.html  UI
data/              the two source files
tests/             unittest suite
docs/AI_COLLABORATION.md   planning / brainstorming notes
```

## Time spent

_Fill in your own honest number before submitting_ (e.g. "~X h: data audit, Y h: reconciliation logic, Z h: API/UI, W h: README/tests").
